package com.example.des.hp.myutils;

public class MyDateDiff
{
    public int year;
    public int month;
    public int day;
    public int days;
}
