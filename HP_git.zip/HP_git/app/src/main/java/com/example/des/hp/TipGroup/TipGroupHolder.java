package com.example.des.hp.TipGroup;

import android.widget.ImageView;
import android.widget.TextView;

/**
 ** Created by Des on 30/10/2016.
 */

public class TipGroupHolder
{
    public ImageView fileImage;
    public TextView txtTitle;
    public TextView txtTaskDate;
}
