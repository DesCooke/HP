package com.example.des.hp.InternalFiles;


public class InternalFileItem
{
    public String filename;

    public InternalFileItem(String argFilename)
    {
        filename=argFilename;
    }

}
