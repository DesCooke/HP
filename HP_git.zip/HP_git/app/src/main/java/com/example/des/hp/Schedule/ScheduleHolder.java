package com.example.des.hp.Schedule;

import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 ** Created by Des on 30/10/2016.
 */

public class ScheduleHolder
{
    public ImageView scheduleTypeImage;
    public ImageView scheduleImage;
    public TextView txtSchedName;
    public TextView txtTimeRange;
    public LinearLayout scheduleItemCell;
    public TextView txtReservationType;
}
