package com.example.des.hp.Tip;

import android.widget.ImageView;
import android.widget.TextView;

/**
 ** Created by Des on 30/10/2016.
 */

public class TipHolder
{
    public ImageView fileImage;
    public TextView txtTitle;
    public TextView txtTaskDate;
    public TextView txtNotes;
}
