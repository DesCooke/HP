package com.example.des.hp.Day;

import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 ** Created by Des on 30/10/2016.
 */

public class DayHolder
{
    public ImageView dayImage;
    public TextView txtTitle;
    public TextView txtStartDate;
    public TextView txtRange;
    public TextView txtHours;
    public int minutesScheduled;
    public LinearLayout dayFullCell;
}
