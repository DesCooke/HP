package com.example.des.hp.Dialog;

public class BaseItem
{
}
