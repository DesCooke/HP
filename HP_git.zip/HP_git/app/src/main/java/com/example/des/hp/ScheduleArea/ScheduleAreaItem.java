package com.example.des.hp.ScheduleArea;

public class ScheduleAreaItem
{
    // Fields
    public int holidayId;
    public int attractionId;
    public int attractionAreaId;
    public int dayId;
    public int scheduleId;
    public String schedName;
    public String schedDesc;

    public ScheduleAreaItem()
    {
        schedName="";
        schedDesc="";
    }

}
