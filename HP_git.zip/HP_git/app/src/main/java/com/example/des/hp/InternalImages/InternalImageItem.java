package com.example.des.hp.InternalImages;


public class InternalImageItem
{
    public String internalImageFilename;

    public InternalImageItem(String argFilename, int argUsageCount)
    {
        internalImageFilename=argFilename;
    }

}
