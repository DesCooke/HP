package com.example.des.hp.myutils;

import android.graphics.Bitmap;

//
// Simple class used to allow bitmaps to be passed as parameters
//
public class MyBitmap
{
    public Bitmap Value;
}
