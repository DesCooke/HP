package com.example.des.hp.Notes;

public class NoteItem
{
    // Fields
    public int holidayId;
    public int noteId;
    public String notes;

    // Original Fields
    public int origHolidayId;
    public int origNoteId;
    public String origNotes;

    public NoteItem()
    {
        notes="";
    }

}
