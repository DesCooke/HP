package com.example.des.hp.myutils;

//
// Simple class used to allow booleans to be passed as parameters
//

public class MyBoolean
{
    public boolean Value;
}
