package com.example.des.hp.ExtraFiles;

import android.widget.ImageView;
import android.widget.TextView;

/**
 ** Created by Des on 30/10/2016.
 */

public class ExtraFilesHolder
{
    public ImageView fileImage;
    public TextView txtTitle;
}
