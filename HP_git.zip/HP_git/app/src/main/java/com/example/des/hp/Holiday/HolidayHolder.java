package com.example.des.hp.Holiday;

import android.widget.ImageView;
import android.widget.TextView;

/**
 * * Created by Des on 30/10/2016.
 */

class HolidayHolder
{
    ImageView holidayImage;
    TextView txtTitle;
    TextView txtStartDate;
    TextView txtToGo;
}
