package com.example.des.hp.myutils;

public class MyString
{
    public String Value;
}
