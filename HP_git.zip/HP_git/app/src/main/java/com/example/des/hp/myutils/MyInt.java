package com.example.des.hp.myutils;

public class MyInt
{
    public int Value;
}
