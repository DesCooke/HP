package com.example.des.hp.myutils;

public class MyLong
{
    public long Value;
}
