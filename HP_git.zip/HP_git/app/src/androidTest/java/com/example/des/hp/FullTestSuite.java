package com.example.des.hp;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({MainActivityAddHoliday001.class})
public class FullTestSuite
{
}
